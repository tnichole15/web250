
  <footer>
    <p><small>Copyright 2022</small>, Birds of WNC</p>
    <p>Resource 
      <a href="#">Cornell Ornathology Lab</a>
    </p>
  </footer>
  </body>
</html>
