<footer>
  &copy; <?php echo date('Y'); ?> Chain Gang
</footer>

</body>
</html>

<?php
  db_disconnect($database);
?>
